IPO AARTHI — WEBSITE STARTER

Open index.html in a modern browser. Features:
- Responsive temple-inspired three-panel interface
- Deity gallery with search and category filters
- Each deity has a vahana companion with gentle head-nod animation
- Click the vahana to trigger a cute action and flower shower
- Optional automatic flower offerings during automatic Aarthi
- Manual plate movement by touch/mouse drag
- Automatic plate rotation
- Bell and browser-generated soft tones
- WhatsApp share and downloadable blessing card

Important:
- Deity and vahana visuals currently use emoji/symbolic artwork as lightweight placeholders, not a complete archive of deity photographs.
- Use only devotional images/audio you own or have permission to use when replacing placeholders.
- No user data is uploaded to a server. This is a static front-end prototype.
- Aarthi is devotional entertainment and cannot affect IPO allotment or investment outcomes.

Free hosting:
Upload index.html to a GitHub repository and enable GitHub Pages in Settings > Pages. GitHub Pages supports static sites; a custom domain is optional and generally costs extra.
